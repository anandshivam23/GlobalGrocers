document.addEventListener('DOMContentLoaded', function() {
    // Password toggle visibility
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordInput = this.parentElement.querySelector('input');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            }
        });
    });
    
    // Password strength meter
    const passwordInput = document.getElementById('password');
    const strengthBar = document.querySelector('.bar-level');
    const strengthText = document.querySelector('.strength-text');
    
    if (passwordInput && strengthBar && strengthText) {
        passwordInput.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;
            
            // Check length
            if (value.length >= 8) strength += 25;
            
            // Check for lowercase and uppercase letters
            if (value.match(/[a-z]/) && value.match(/[A-Z]/)) strength += 25;
            
            // Check for numbers
            if (value.match(/\d/)) strength += 25;
            
            // Check for special characters
            if (value.match(/[^a-zA-Z0-9]/)) strength += 25;
            
            // Update strength bar
            strengthBar.style.width = `${strength}%`;
            
            // Update color based on strength
            if (strength <= 25) {
                strengthBar.style.backgroundColor = '#F44336'; // Red
                strengthText.textContent = 'Weak';
            } else if (strength <= 50) {
                strengthBar.style.backgroundColor = '#FFC107'; // Yellow
                strengthText.textContent = 'Fair';
            } else if (strength <= 75) {
                strengthBar.style.backgroundColor = '#2196F3'; // Blue
                strengthText.textContent = 'Good';
            } else {
                strengthBar.style.backgroundColor = '#4CAF50'; // Green
                strengthText.textContent = 'Strong';
            }
        });
    }
    
    // Signup form validation
    const signupForm = document.getElementById('signup-form');
    
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const firstName = document.getElementById('first_name').value;
            const lastName = document.getElementById('last_name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const terms = document.getElementById('terms').checked;
            
            // Reset any existing error messages
            const authMessages = document.getElementById('auth-messages');
            authMessages.innerHTML = '';
            
            // Validation
            if (!firstName || !lastName || !email || !phone || !password || !confirmPassword) {
                showAuthMessage('Please fill in all required fields.', 'error');
                return;
            }
            
            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                showAuthMessage('Please enter a valid email address.', 'error');
                return;
            }
            
            // Phone validation
            const phonePattern = /^\d{10}$/;
            if (!phonePattern.test(phone.replace(/\D/g, ''))) {
                showAuthMessage('Please enter a valid 10-digit phone number.', 'error');
                return;
            }
            
            // Password length
            if (password.length < 8) {
                showAuthMessage('Password must be at least 8 characters long.', 'error');
                return;
            }
            
            // Password match
            if (password !== confirmPassword) {
                showAuthMessage('Passwords do not match.', 'error');
                return;
            }
            
            // Terms agreement
            if (!terms) {
                showAuthMessage('You must agree to the Terms of Service and Privacy Policy.', 'error');
                return;
            }
            
            // If all validations pass, submit the form
            // For demo purposes, redirect to home page
            window.location.href = '../index.html';
        });
    }
    
    // Login form validation
    const loginForm = document.getElementById('login-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Reset any existing error messages
            const authMessages = document.getElementById('auth-messages');
            authMessages.innerHTML = '';
            
            // Validation
            if (!email || !password) {
                showAuthMessage('Please enter both email and password.', 'error');
                return;
            }
            
            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                showAuthMessage('Please enter a valid email address.', 'error');
                return;
            }
            
            // If all validations pass, submit the form
            // For demo purposes, redirect to home page
            window.location.href = '../index.html';
        });
    }
    
    // Forgot password form validation
    const forgotPasswordForm = document.getElementById('forgot-password-form');
    
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            
            // Reset any existing error messages
            const authMessages = document.getElementById('auth-messages');
            
            // Validation
            if (!email) {
                showAuthMessage('Please enter your email address.', 'error');
                return;
            }
            
            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                showAuthMessage('Please enter a valid email address.', 'error');
                return;
            }
            
            // Show success message
            showAuthMessage('Password reset link has been sent to your email.', 'success');
            
            // Clear the email field
            document.getElementById('email').value = '';
        });
    }
    
    // Helper function to show auth messages
    function showAuthMessage(message, type) {
        const authMessages = document.getElementById('auth-messages');
        if (!authMessages) return;
        
        authMessages.innerHTML = `
            <div class="auth-message ${type}">
                ${message}
            </div>
        `;
    }
});