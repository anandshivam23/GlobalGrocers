
-- Create database
CREATE DATABASE IF NOT EXISTS grocery_store;
USE grocery_store;

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(20),
    bg_color VARCHAR(20)
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    original_price DECIMAL(10, 2),
    image_url VARCHAR(255),
    category VARCHAR(50),
    rating DECIMAL(3, 1) DEFAULT 0,
    is_new BOOLEAN DEFAULT FALSE,
    is_sale BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category) REFERENCES categories(id)
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Carts table
CREATE TABLE IF NOT EXISTS carts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Cart items table
CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    shipping_address TEXT NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Sample data for categories
INSERT INTO categories (id, name, description, icon, bg_color) VALUES
('fruits', 'Fruits', 'Fresh seasonal fruits', '🍎', 'var(--green-100)'),
('dairy', 'Dairy', 'Milk, cheese & yogurt', '🥛', 'var(--blue-100)'),
('bakery', 'Bakery', 'Fresh baked goods', '🍞', 'var(--amber-100)'),
('meat', 'Meat', 'Fresh & quality meats', '🥩', 'var(--rose-100)'),
('frozen', 'Frozen', 'Frozen meals & treats', '❄️', '#E0F7FA'),
('pantry', 'Pantry', 'Essential kitchen staples', '🥫', '#FFF3E0'),
('beverages', 'Beverages', 'Drinks & refreshments', '🍹', 'var(--purple-100)'),
('snacks', 'Snacks', 'Chips, nuts & more', '🍿', '#FFFDE7');

-- Sample data for products
INSERT INTO products (name, description, price, original_price, image_url, category, rating, is_new, is_sale) VALUES
('Organic Avocados', 'Freshly picked organic avocados, perfect for guacamole or toast.', 4.99, NULL, 'images/avocado.jpg', 'fruits', 4.8, TRUE, FALSE),
('Fresh Strawberries', 'Sweet and juicy strawberries, perfect for desserts or snacking.', 3.49, 4.99, 'images/strawberry.jpg', 'fruits', 4.6, FALSE, TRUE),
('Artisan Sourdough Bread', 'Freshly baked artisan sourdough bread with a crispy crust.', 5.99, NULL, 'images/bread.jpg', 'bakery', 4.9, FALSE, FALSE),
('Organic Milk', 'Farm-fresh organic milk, hormone and antibiotic-free.', 3.29, NULL, 'images/milk.jpg', 'dairy', 4.7, FALSE, FALSE),
('Organic Bananas', 'Organic bananas from sustainable farms, perfect for smoothies.', 1.99, NULL, 'images/banana.jpg', 'fruits', 4.5, FALSE, FALSE),
('Greek Yogurt', 'Creamy Greek yogurt, high in protein and probiotics.', 2.99, NULL, 'images/yogurt.jpg', 'dairy', 4.6, FALSE, FALSE),
('Whole Grain Rolls', 'Nutritious whole grain rolls, perfect for sandwiches.', 4.49, 5.99, 'images/rolls.jpg', 'bakery', 4.3, FALSE, TRUE),
('Premium Rib Eye Steak', 'Premium quality rib eye steak, perfect for grilling.', 15.99, NULL, 'images/steak.jpg', 'meat', 4.9, FALSE, FALSE);
