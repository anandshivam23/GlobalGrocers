
<?php
require_once 'config.php';

// Get all categories
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->query("SELECT * FROM categories");
        $categories = $stmt->fetchAll();
        
        response($categories);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to fetch categories"], 500);
    }
}

// Get single category
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    try {
        $id = $_GET['id'];
        
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        $category = $stmt->fetch();
        
        if (!$category) {
            response(["error" => "Category not found"], 404);
        }
        
        response($category);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to fetch category"], 500);
    }
}
?>
