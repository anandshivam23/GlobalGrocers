
<?php
require_once 'config.php';

// Get products
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $category = isset($_GET['category']) ? $_GET['category'] : null;
        $sort = isset($_GET['sort']) ? $_GET['sort'] : 'popular';
        
        $sql = "SELECT * FROM products";
        
        if ($category) {
            $sql .= " WHERE category = :category";
        }
        
        // Add sorting
        switch ($sort) {
            case 'price-low':
                $sql .= " ORDER BY price ASC";
                break;
            case 'price-high':
                $sql .= " ORDER BY price DESC";
                break;
            case 'newest':
                $sql .= " ORDER BY created_at DESC";
                break;
            default: // popular
                $sql .= " ORDER BY rating DESC";
        }
        
        $stmt = $pdo->prepare($sql);
        
        if ($category) {
            $stmt->bindParam(':category', $category);
        }
        
        $stmt->execute();
        $products = $stmt->fetchAll();
        
        response($products);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to fetch products"], 500);
    }
}

// Get single product
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    try {
        $id = $_GET['id'];
        
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        $product = $stmt->fetch();
        
        if (!$product) {
            response(["error" => "Product not found"], 404);
        }
        
        response($product);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to fetch product"], 500);
    }
}
?>
