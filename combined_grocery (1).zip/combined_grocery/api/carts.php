
<?php
require_once 'config.php';

// Helper function to validate cart items
function validateCartItem($item) {
    // In a real app, you'd validate against database records
    return isset($item['id']) && isset($item['quantity']) && $item['quantity'] > 0;
}

// Create or update cart
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = getRequestData();
        
        if (!isset($data['userId']) || !isset($data['items']) || !is_array($data['items'])) {
            response(["error" => "Invalid request data"], 400);
        }
        
        $userId = $data['userId'];
        $items = $data['items'];
        
        // Validate items
        foreach ($items as $item) {
            if (!validateCartItem($item)) {
                response(["error" => "Invalid cart item"], 400);
            }
        }
        
        // Check if user has a cart
        $stmt = $pdo->prepare("SELECT id FROM carts WHERE user_id = :userId");
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
        $cart = $stmt->fetch();
        
        $pdo->beginTransaction();
        
        if ($cart) {
            // Update existing cart
            $cartId = $cart['id'];
            
            // Delete existing items
            $stmt = $pdo->prepare("DELETE FROM cart_items WHERE cart_id = :cartId");
            $stmt->bindParam(':cartId', $cartId);
            $stmt->execute();
        } else {
            // Create new cart
            $stmt = $pdo->prepare("INSERT INTO carts (user_id, created_at) VALUES (:userId, NOW())");
            $stmt->bindParam(':userId', $userId);
            $stmt->execute();
            
            $cartId = $pdo->lastInsertId();
        }
        
        // Add new items
        $stmt = $pdo->prepare("INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (:cartId, :productId, :quantity)");
        
        foreach ($items as $item) {
            $stmt->bindParam(':cartId', $cartId);
            $stmt->bindParam(':productId', $item['id']);
            $stmt->bindParam(':quantity', $item['quantity']);
            $stmt->execute();
        }
        
        $pdo->commit();
        
        response(["success" => true, "cartId" => $cartId]);
    } catch(PDOException $e) {
        $pdo->rollBack();
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to update cart"], 500);
    }
}

// Get cart
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['userId'])) {
    try {
        $userId = $_GET['userId'];
        
        // Get cart
        $stmt = $pdo->prepare("
            SELECT c.id as cart_id, ci.product_id, ci.quantity, p.name, p.price, p.image_url 
            FROM carts c
            JOIN cart_items ci ON c.id = ci.cart_id
            JOIN products p ON ci.product_id = p.id
            WHERE c.user_id = :userId
        ");
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
        
        $items = $stmt->fetchAll();
        
        if (empty($items)) {
            response(["items" => []]);
        }
        
        // Format response
        $cartItems = [];
        foreach ($items as $item) {
            $cartItems[] = [
                'id' => $item['product_id'],
                'name' => $item['name'],
                'price' => (float) $item['price'],
                'imageUrl' => $item['image_url'],
                'quantity' => (int) $item['quantity']
            ];
        }
        
        response(["items" => $cartItems]);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to fetch cart"], 500);
    }
}

// Delete cart
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['userId'])) {
    try {
        $userId = $_GET['userId'];
        
        // Get cart ID
        $stmt = $pdo->prepare("SELECT id FROM carts WHERE user_id = :userId");
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
        
        $cart = $stmt->fetch();
        
        if (!$cart) {
            response(["success" => true]); // Cart already empty
        }
        
        $cartId = $cart['id'];
        
        $pdo->beginTransaction();
        
        // Delete cart items
        $stmt = $pdo->prepare("DELETE FROM cart_items WHERE cart_id = :cartId");
        $stmt->bindParam(':cartId', $cartId);
        $stmt->execute();
        
        // Delete cart
        $stmt = $pdo->prepare("DELETE FROM carts WHERE id = :cartId");
        $stmt->bindParam(':cartId', $cartId);
        $stmt->execute();
        
        $pdo->commit();
        
        response(["success" => true]);
    } catch(PDOException $e) {
        $pdo->rollBack();
        error_log("Database error: " . $e->getMessage());
        response(["error" => "Failed to delete cart"], 500);
    }
}
?>
